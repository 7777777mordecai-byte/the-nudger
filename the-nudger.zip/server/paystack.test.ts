import { describe, it, expect } from "vitest";

describe("Paystack API Keys Validation", () => {
  it("should validate Paystack secret key is available", () => {
    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    expect(secretKey).toBeDefined();
    expect(secretKey).toMatch(/^sk_(test|live)_/);
  });

  it("should validate Paystack public key is available", () => {
    const publicKey = process.env.VITE_PAYSTACK_PUBLIC_KEY;
    expect(publicKey).toBeDefined();
    expect(publicKey).toMatch(/^pk_(test|live)_/);
  });

  it("should have valid Paystack key format", () => {
    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    const publicKey = process.env.VITE_PAYSTACK_PUBLIC_KEY;

    // Verify keys are in the correct format (supports both test and live keys)
    expect(secretKey).toMatch(/^sk_(test|live)_[a-f0-9]+$/);
    expect(publicKey).toMatch(/^pk_(test|live)_[a-f0-9]+$/);

    // Keys should be different
    expect(secretKey).not.toBe(publicKey);
  });

  it(
    "should be able to authenticate with Paystack API",
    async () => {
      const secretKey = process.env.PAYSTACK_SECRET_KEY;
      if (!secretKey) {
        throw new Error("PAYSTACK_SECRET_KEY not set");
      }

      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        const response = await fetch("https://api.paystack.co/customer", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${secretKey}`,
            "Content-Type": "application/json",
          },
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        // 200 or 400 means the key is valid (400 would be for bad request params, not auth)
        // 401 would mean invalid key
        expect(response.status).not.toBe(401);
        expect(response.ok || response.status === 400).toBe(true);
      } catch (error) {
        if ((error as Error).name === "AbortError") {
          console.warn("Paystack API test timed out - network may be slow");
          // Don't fail on timeout, just warn
        } else {
          console.error("Paystack API test error:", error);
          throw error;
        }
      }
    },
    { timeout: 15000 }
  );
});
