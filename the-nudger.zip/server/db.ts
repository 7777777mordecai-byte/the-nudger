import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, clients, InsertClient, Client } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get all clients for a specific user
 */
export async function getUserClients(userId: number): Promise<Client[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get clients: database not available");
    return [];
  }

  try {
    const result = await db.select().from(clients).where(eq(clients.userId, userId));
    return result;
  } catch (error) {
    console.error("[Database] Failed to get user clients:", error);
    return [];
  }
}

/**
 * Create a new client for a user
 */
export async function createClient(userId: number, clientData: Omit<InsertClient, 'userId'>): Promise<Client | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create client: database not available");
    return null;
  }

  try {
    await db.insert(clients).values({
      ...clientData,
      userId,
    });
    
    const createdClients = await db.select().from(clients).where(eq(clients.userId, userId));
    return createdClients.length > 0 ? createdClients[createdClients.length - 1] : null;
  } catch (error) {
    console.error("[Database] Failed to create client:", error);
    return null;
  }
}

/**
 * Update a client
 */
export async function updateClient(clientId: number, updates: Partial<Omit<InsertClient, 'userId'>>): Promise<Client | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update client: database not available");
    return null;
  }

  try {
    await db.update(clients).set(updates).where(eq(clients.id, clientId));
    
    const result = await db.select().from(clients).where(eq(clients.id, clientId)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to update client:", error);
    return null;
  }
}

/**
 * Delete a client
 */
export async function deleteClient(clientId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete client: database not available");
    return false;
  }

  try {
    await db.delete(clients).where(eq(clients.id, clientId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete client:", error);
    return false;
  }
}


/**
 * Update user subscription tier
 */
export async function updateUserSubscription(
  userId: number,
  tier: "free" | "weekly" | "monthly" | "yearly",
  expiresAt?: Date
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update subscription: database not available");
    return false;
  }

  try {
    await db.update(users).set({
      subscriptionTier: tier,
      subscriptionExpiresAt: expiresAt || null,
    }).where(eq(users.id, userId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to update subscription:", error);
    return false;
  }
}

/**
 * Get user subscription info
 */
export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get subscription: database not available");
    return null;
  }

  try {
    const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (result.length === 0) return null;

    const user = result[0];
    return {
      tier: user.subscriptionTier,
      expiresAt: user.subscriptionExpiresAt,
      isPremium: user.subscriptionTier !== "free",
    };
  } catch (error) {
    console.error("[Database] Failed to get subscription:", error);
    return null;
  }
}
