import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getUserClients, createClient, updateClient, deleteClient, updateUserSubscription, getUserSubscription } from "./db";

// Subscription plans configuration with Paystack amounts in Naira
const SUBSCRIPTION_PLANS = {
  weekly: {
    name: "Weekly Premium",
    priceNaira: 9999, // ~$6.50 USD
    priceUSD: 650,
    priceEUR: 600,
    interval: "week",
    durationDays: 7,
  },
  monthly: {
    name: "Monthly Premium",
    priceNaira: 29999, // ~$19.50 USD
    priceUSD: 1950,
    priceEUR: 1800,
    interval: "month",
    durationDays: 30,
  },
  yearly: {
    name: "Yearly Premium",
    priceNaira: 249999, // ~$162 USD (30% savings)
    priceUSD: 16200,
    priceEUR: 15000,
    interval: "year",
    durationDays: 365,
  },
};

// Currency to Naira conversion rates (approximate)
const CURRENCY_RATES: Record<string, number> = {
  NGN: 1,
  USD: 1540, // 1 USD = ~1540 NGN
  EUR: 1680, // 1 EUR = ~1680 NGN
};

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  subscription: router({
    /**
     * Get current user subscription status
     */
    getStatus: protectedProcedure.query(async ({ ctx }) => {
      const subscription = await getUserSubscription(ctx.user.id);
      return {
        tier: subscription?.tier || "free",
        isPremium: subscription?.isPremium || false,
        expiresAt: subscription?.expiresAt,
      };
    }),

    /**
     * Initialize Paystack payment
     */
    initializePayment: protectedProcedure
      .input(
        z.object({
          plan: z.enum(["weekly", "monthly", "yearly"]),
          currency: z.enum(["NGN", "USD", "EUR"]).default("NGN"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const plan = SUBSCRIPTION_PLANS[input.plan];
        if (!plan) {
          throw new Error("Invalid subscription plan");
        }

        // Get price in the selected currency
        const priceKey = `price${input.currency}` as keyof typeof plan;
        const amount = (plan[priceKey] as number) || plan.priceNaira;

        // Convert to Naira if needed (Paystack uses Naira)
        const amountInNaira =
          input.currency === "NGN" ? amount : Math.round(amount * (CURRENCY_RATES[input.currency] || 1));

        const secretKey = process.env.PAYSTACK_SECRET_KEY;
        if (!secretKey) {
          throw new Error("Paystack configuration missing");
        }

        try {
          const response = await fetch("https://api.paystack.co/transaction/initialize", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${secretKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: ctx.user.email,
              amount: amountInNaira, // Paystack expects amount in kobo (1/100 of Naira)
              currency: "NGN",
              metadata: {
                user_id: ctx.user.id,
                plan: input.plan,
                currency: input.currency,
                plan_name: plan.name,
              },
              callback_url: `${ctx.req.headers.origin}/payment-callback`,
            }),
          });

          if (!response.ok) {
            const error = await response.json();
            console.error("Paystack initialization error:", error);
            throw new Error("Failed to initialize payment");
          }

          const data = (await response.json()) as {
            status: boolean;
            message: string;
            data: {
              authorization_url: string;
              access_code: string;
              reference: string;
            };
          };

          if (!data.status) {
            throw new Error(data.message || "Payment initialization failed");
          }

          // Store the reference for later verification
          console.log(`[Paystack] Payment initialized for user ${ctx.user.id}, reference: ${data.data.reference}`);

          return {
            success: true,
            authorizationUrl: data.data.authorization_url,
            accessCode: data.data.access_code,
            reference: data.data.reference,
            amount: amountInNaira,
            currency: "NGN",
            plan: input.plan,
            planName: plan.name,
          };
        } catch (error) {
          console.error("[Paystack] Initialization error:", error);
          throw new Error("Failed to initialize payment with Paystack");
        }
      }),

    /**
     * Verify Paystack payment and activate subscription
     */
    verifyPayment: protectedProcedure
      .input(
        z.object({
          reference: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const secretKey = process.env.PAYSTACK_SECRET_KEY;
        if (!secretKey) {
          throw new Error("Paystack configuration missing");
        }

        try {
          const response = await fetch(`https://api.paystack.co/transaction/verify/${input.reference}`, {
            method: "GET",
            headers: {
              Authorization: `Bearer ${secretKey}`,
            },
          });

          if (!response.ok) {
            throw new Error("Failed to verify payment");
          }

          const data = (await response.json()) as {
            status: boolean;
            message: string;
            data: {
              status: string;
              reference: string;
              amount: number;
              metadata: {
                user_id: number;
                plan: string;
                plan_name: string;
              };
            };
          };

          if (!data.status || data.data.status !== "success") {
            throw new Error("Payment verification failed");
          }

          // Verify the payment belongs to this user
          if (data.data.metadata.user_id !== ctx.user.id) {
            throw new Error("Payment user mismatch");
          }

          const plan = data.data.metadata.plan as "weekly" | "monthly" | "yearly";
          const planConfig = SUBSCRIPTION_PLANS[plan];

          if (!planConfig) {
            throw new Error("Invalid plan in payment metadata");
          }

          // Calculate expiration date
          const expiresAt = new Date();
          expiresAt.setDate(expiresAt.getDate() + planConfig.durationDays);

          // Update user subscription in database
          const success = await updateUserSubscription(ctx.user.id, plan, expiresAt);

          if (!success) {
            throw new Error("Failed to activate subscription");
          }

          console.log(
            `[Paystack] Payment verified and subscription activated for user ${ctx.user.id}, plan: ${plan}`
          );

          return {
            success: true,
            tier: plan,
            planName: planConfig.name,
            expiresAt,
            message: `Successfully upgraded to ${planConfig.name}! Your subscription is now active.`,
          };
        } catch (error) {
          console.error("[Paystack] Verification error:", error);
          throw new Error("Payment verification failed");
        }
      }),

    /**
     * Mock checkout for testing (kept for backwards compatibility)
     */
    checkout: protectedProcedure
      .input(
        z.object({
          plan: z.enum(["weekly", "monthly", "yearly"]),
          cardNumber: z.string(),
          expiryDate: z.string(),
          cvc: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Mock payment validation (accept any card info for demo)
        if (!input.cardNumber || !input.expiryDate || !input.cvc) {
          throw new Error("Invalid payment information");
        }

        const plan = SUBSCRIPTION_PLANS[input.plan];
        if (!plan) {
          throw new Error("Invalid subscription plan");
        }

        // Calculate expiration date
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + plan.durationDays);

        // Update user subscription in database
        const success = await updateUserSubscription(ctx.user.id, input.plan, expiresAt);

        if (!success) {
          throw new Error("Failed to activate subscription");
        }

        console.log(`[Subscription] User ${ctx.user.id} upgraded to ${input.plan} plan`);

        return {
          success: true,
          tier: input.plan,
          planName: plan.name,
          expiresAt,
          message: `Successfully upgraded to ${plan.name}! Your subscription is active.`,
        };
      }),
  }),

  clients: router({
    /**
     * Get all clients for the authenticated user
     */
    list: protectedProcedure.query(async ({ ctx }) => {
      const userClients = await getUserClients(ctx.user.id);
      return userClients.map((client) => ({
        id: client.id,
        name: client.name,
        amount: client.amount,
        daysLate: client.daysLate,
        whatsappEnabled: client.whatsappEnabled === 1,
        phone: client.phone,
      }));
    }),

    /**
     * Create a new client
     */
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1, "Client name is required"),
          amount: z.number().positive("Amount must be positive"),
          phone: z.string().min(1, "Phone number is required"),
          daysLate: z.number().int().nonnegative().optional().default(0),
          whatsappEnabled: z.boolean().optional().default(true),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const newClient = await createClient(ctx.user.id, {
          name: input.name,
          amount: input.amount,
          phone: input.phone,
          daysLate: input.daysLate,
          whatsappEnabled: input.whatsappEnabled ? 1 : 0,
        });

        if (!newClient) {
          throw new Error("Failed to create client");
        }

        return {
          id: newClient.id,
          name: newClient.name,
          amount: newClient.amount,
          daysLate: newClient.daysLate,
          whatsappEnabled: newClient.whatsappEnabled === 1,
          phone: newClient.phone,
        };
      }),

    /**
     * Update a client
     */
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          amount: z.number().positive().optional(),
          daysLate: z.number().int().nonnegative().optional(),
          whatsappEnabled: z.boolean().optional(),
          phone: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;

        const updateData: Record<string, unknown> = {};
        if (updates.name !== undefined) updateData.name = updates.name;
        if (updates.amount !== undefined) updateData.amount = updates.amount;
        if (updates.daysLate !== undefined) updateData.daysLate = updates.daysLate;
        if (updates.whatsappEnabled !== undefined) updateData.whatsappEnabled = updates.whatsappEnabled ? 1 : 0;
        if (updates.phone !== undefined) updateData.phone = updates.phone;

        const updated = await updateClient(id, updateData);

        if (!updated) {
          throw new Error("Failed to update client");
        }

        return {
          id: updated.id,
          name: updated.name,
          amount: updated.amount,
          daysLate: updated.daysLate,
          whatsappEnabled: updated.whatsappEnabled === 1,
          phone: updated.phone,
        };
      }),

    /**
     * Delete a client
     */
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const success = await deleteClient(input.id);
        if (!success) {
          throw new Error("Failed to delete client");
        }
        return { success: true };
      }),
  }),

  whatsapp: router({
    sendNudge: publicProcedure
      .input(
        z.object({
          clientName: z.string(),
          amount: z.number(),
          daysLate: z.number(),
          phone: z.string(),
          messageType: z.enum(["reminder", "firstInvoice"]),
        })
      )
      .mutation(async ({ input }) => {
        // Construct WhatsApp message based on type
        let message = "";

        if (input.messageType === "firstInvoice") {
          message = `Hi ${input.clientName}, 👋\n\nWe've sent you an invoice for $${input.amount}. Please review and process payment at your earliest convenience.\n\nThank you!`;
        } else {
          // Reminder message for overdue invoices
          const urgency =
            input.daysLate >= 15
              ? "URGENT: "
              : input.daysLate >= 8
                ? "Reminder: "
                : "";
          message = `${urgency}Hi ${input.clientName}, 📢\n\nThis is a friendly reminder that your invoice for $${input.amount} is now ${input.daysLate} days overdue.\n\nPlease settle this payment as soon as possible.\n\nThank you!`;
        }

        // Generate WhatsApp click-to-chat URL
        // Format: https://wa.me/{phone}?text={message}
        const encodedMessage = encodeURIComponent(message);
        const whatsappUrl = `https://wa.me/${input.phone.replace(/[^\d+]/g, "")}?text=${encodedMessage}`;

        // Log the action (in production, this would be stored in database)
        console.log(`[WhatsApp] Nudge sent to ${input.clientName} (${input.phone})`);
        console.log(`[WhatsApp] Message: ${message}`);
        console.log(`[WhatsApp] URL: ${whatsappUrl}`);

        // Return the WhatsApp URL for the frontend to open
        return {
          success: true,
          url: whatsappUrl,
          message,
          clientName: input.clientName,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
