ALTER TABLE `users` ADD `subscriptionTier` varchar(20) DEFAULT 'free' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `subscriptionExpiresAt` timestamp;