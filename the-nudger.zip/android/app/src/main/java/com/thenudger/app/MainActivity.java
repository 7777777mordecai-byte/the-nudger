package com.thenudger.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
