import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.thenudger.app',
  appName: 'The Nudger',
  webDir: 'dist',
  server: {
    // In development, use local dist. In production, use live Manus URL
    url: process.env.CAPACITOR_SERVER_URL || 'http://localhost:5173',
    cleartext: true,
  },
  android: {
    allowMixedContent: true,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0,
    },
  },
};

export default config;
