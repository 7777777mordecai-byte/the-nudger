# GitHub Setup Instructions for The Nudger

Follow these steps to set up your GitHub repository for automated APK builds.

## Step 1: Create a GitHub Repository

1. Go to https://github.com/new
2. Create a new repository:
   - **Repository name**: `the-nudger` (or your preferred name)
   - **Description**: "The Nudger - Invoice Reminder App"
   - **Visibility**: Public (required for free GitHub Actions)
   - **Initialize with**: None (we'll push existing code)

3. Click **Create repository**

## Step 2: Push Your Code to GitHub

In your local terminal:

```bash
cd /home/ubuntu/the-nudger

# Initialize git (if not already done)
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: The Nudger with Capacitor and GitHub Actions"

# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/the-nudger.git

# Push to GitHub
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

## Step 3: Verify GitHub Actions

1. Go to your repository on GitHub
2. Click the **Actions** tab
3. You should see the **Build Android APK** workflow
4. The workflow will automatically trigger on:
   - Push to `main`, `master`, or `develop` branches
   - Pull requests to these branches
   - Manual trigger via **Run workflow** button

## Step 4: Download Your First APK

### Option A: Automatic Build (Recommended)

1. Make a small change to any file (e.g., update README)
2. Commit and push:
   ```bash
   git add .
   git commit -m "Trigger APK build"
   git push
   ```
3. Go to **Actions** tab
4. Wait for the **Build Android APK** workflow to complete (5-10 minutes)
5. Click the workflow run
6. Scroll to **Artifacts** section
7. Download `the-nudger-apk.zip`

### Option B: Manual Trigger

1. Go to **Actions** tab
2. Click **Build Android APK** workflow
3. Click **Run workflow** button
4. Select your branch
5. Click **Run workflow**
6. Wait for completion and download artifacts

## Step 5: Test the APK

1. Download the APK from artifacts
2. Transfer to your Android device or use Android emulator
3. Install:
   ```bash
   adb install The-Nudger-release.apk
   ```
4. Test the app:
   - Login with demo credentials
   - Create an invoice
   - Verify WhatsApp integration
   - Check Paystack payment flow

## Step 6: Create a Release (Optional)

To create a versioned release with the APK:

```bash
# Create a git tag
git tag v1.0.0

# Push the tag
git push origin v1.0.0
```

GitHub will automatically:
1. Trigger the build workflow
2. Create a GitHub Release
3. Attach the APK to the release

You can then download from the **Releases** page.

## Step 7: Submit to App Stores

Once you have the APK:

### Samsung Galaxy Store

1. Register at https://seller.samsungapps.com
2. Create a new app:
   - **App Name**: The Nudger
   - **Package ID**: com.thenudger.app
   - **APK File**: Upload `The-Nudger-release.apk`
3. Fill in store listing details
4. Submit for review (typically 24-48 hours)

### Palmstore

1. Register at https://palmstore.com/developer
2. Follow similar steps as Galaxy Store
3. Upload APK and submit

## Troubleshooting

### Workflow Not Running

- Ensure repository is **public** (private repos have limited free Actions)
- Check that `.github/workflows/build-apk.yml` exists
- Go to **Settings** → **Actions** → ensure Actions are enabled

### Build Fails

1. Click the failed workflow run
2. Expand the step that failed
3. Check the error message
4. Common issues:
   - Missing `pnpm` cache (should auto-install)
   - Android SDK download timeout (retry the workflow)
   - Java version mismatch (workflow uses Java 21)

### APK Too Large

If the APK is >100MB:
- This is normal for Capacitor apps
- Most app stores accept up to 100MB (or 200MB with expansion files)
- Consider splitting into app bundle if needed

## Customizing the Workflow

Edit `.github/workflows/build-apk.yml` to:

- Change the backend URL:
  ```yaml
  env:
    CAPACITOR_SERVER_URL: 'https://your-domain.com'
  ```

- Change build triggers:
  ```yaml
  on:
    push:
      branches: [ main ]  # Only build on main branch
  ```

- Add custom build steps:
  ```yaml
  - name: Your custom step
    run: echo "Custom build step"
  ```

## Next Steps

1. ✅ Create GitHub repository
2. ✅ Push code
3. ✅ Trigger first build
4. ✅ Download and test APK
5. ✅ Submit to app stores
6. 🚀 Monitor app reviews and updates

## Support Resources

- **GitHub Actions Docs**: https://docs.github.com/en/actions
- **Capacitor Docs**: https://capacitorjs.com/docs
- **Android Development**: https://developer.android.com
- **Galaxy Store**: https://developer.samsung.com/galaxy-store
- **Palmstore**: https://palmstore.com/developer

---

**Need Help?**

If you encounter issues:
1. Check the workflow logs in GitHub Actions
2. Review the error messages carefully
3. Consult the relevant documentation
4. Reach out to the community forums

Good luck launching The Nudger! 🚀
