# The Nudger - Android APK Build Guide

This document explains how to build and deploy The Nudger as an Android APK for the Samsung Galaxy Store and Palmstore.

## Overview

The Nudger uses **Capacitor** to wrap the web app as a native Android application. The GitHub Actions workflow automatically builds and signs the APK.

## Architecture

```
┌─────────────────────────────────────┐
│   Android APK (Capacitor Wrapper)   │
├─────────────────────────────────────┤
│   WebView (React Frontend)          │
├─────────────────────────────────────┤
│   HTTPS Connection to Backend       │
├─────────────────────────────────────┤
│   Live Manus Server                 │
│   (nudgerdash-j4eojxpu.manus.space) │
└─────────────────────────────────────┘
```

## Build Process

### 1. Automatic Build (GitHub Actions)

The workflow in `.github/workflows/build-apk.yml` automatically:

1. **Installs dependencies** - pnpm install
2. **Builds the web app** - pnpm build (creates `dist/` folder)
3. **Syncs with Capacitor** - npx cap sync android
4. **Generates signing key** - Creates release.keystore
5. **Builds APK** - Runs Android Gradle build
6. **Signs APK** - Uses jarsigner with release key
7. **Uploads artifact** - Makes APK available for download

### 2. Manual Build (Local)

If you want to build locally:

```bash
# Install dependencies
pnpm install

# Build web app
pnpm build

# Sync with Capacitor
npx cap sync android

# Build APK (requires Android SDK)
cd android
./gradlew assembleRelease

# Sign APK
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
  -keystore ../release.keystore \
  -storepass "thenudger123" \
  -keypass "thenudger123" \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  thenudger
```

## Configuration

### Capacitor Config (`capacitor.config.ts`)

```typescript
server: {
  url: process.env.CAPACITOR_SERVER_URL || 'http://localhost:5173',
  cleartext: true,
}
```

- **Development**: Uses local dev server (http://localhost:5173)
- **Production**: Uses live Manus URL (https://nudgerdash-j4eojxpu.manus.space)

### App Metadata

- **App ID**: com.thenudger.app
- **App Name**: The Nudger
- **Version**: Matches git tags
- **Min SDK**: API 24 (Android 7.0)
- **Target SDK**: API 34 (Android 14)

## Signing Key

The APK is signed with a release key:

- **Keystore**: `release.keystore`
- **Alias**: `thenudger`
- **Algorithm**: RSA 2048-bit
- **Validity**: 10,000 days (~27 years)

⚠️ **Important**: Keep the keystore file safe. You'll need it to update the app in stores.

## Deployment to App Stores

### Samsung Galaxy Store

1. Go to https://seller.samsungapps.com
2. Create a developer account
3. Upload the APK:
   - **File**: `The-Nudger-release.apk`
   - **Package**: com.thenudger.app
   - **Version**: Match your git tag
4. Fill in store listing details
5. Submit for review

### Palmstore

1. Go to https://palmstore.com/developer
2. Create a developer account
3. Upload the APK (same process as Galaxy Store)
4. Submit for review

## Downloading the APK

### From GitHub Actions

1. Go to your repository on GitHub
2. Click **Actions** tab
3. Select the latest **Build Android APK** workflow run
4. Scroll to **Artifacts** section
5. Download `the-nudger-apk.zip`
6. Extract to get `The-Nudger-release.apk`

### From GitHub Releases

If you create a git tag and push:

```bash
git tag v1.0.0
git push origin v1.0.0
```

The workflow automatically creates a GitHub Release with the APK attached.

## Troubleshooting

### Build Fails: "Cannot find Android SDK"

The workflow automatically downloads the Android SDK. If it fails:
- Check your internet connection
- Ensure the repository is public (private repos may have limitations)
- Try re-running the workflow

### APK Won't Install

- Ensure your device is set to allow installation from unknown sources
- Check that the device Android version is 7.0+ (API 24+)
- Verify the APK is signed correctly

### App Won't Connect to Backend

- Verify the live Manus URL is correct in the workflow
- Check that HTTPS is enabled on the backend
- Ensure the app has internet permission (should be automatic)

## App Permissions

The APK automatically includes:

- `INTERNET` - Connect to backend server
- `ACCESS_NETWORK_STATE` - Check network connectivity
- `WRITE_EXTERNAL_STORAGE` - For file operations (if needed)
- `READ_EXTERNAL_STORAGE` - For file operations (if needed)

## Environment Variables

Set these in GitHub Secrets if needed:

```
CAPACITOR_SERVER_URL=https://your-domain.com
```

This overrides the default Manus URL.

## Next Steps

1. **Push to GitHub**: Commit and push all changes
2. **Trigger Build**: Push a commit or tag to start the workflow
3. **Download APK**: Get the APK from GitHub Actions artifacts
4. **Test on Device**: Install on Android phone/tablet
5. **Submit to Stores**: Upload to Galaxy Store and Palmstore

## Support

For issues with:
- **Capacitor**: https://capacitorjs.com/docs
- **Android**: https://developer.android.com
- **GitHub Actions**: https://docs.github.com/en/actions

---

**Last Updated**: June 28, 2026
**The Nudger Version**: 1.0.0
